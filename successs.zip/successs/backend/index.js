

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const helmet = require('helmet');
var useragent = require('express-useragent')
var mongoose =require('mongoose');
var randomstring=require('randomstring');


let app = express();


//Route file requiring (importing)
var category=require("./Routes/categoryRoute");
var pet=require("./Routes/petRoute");
var success=require("./Routes/successRoute");



//BODYPARSER
app.use(bodyParser.urlencoded({
    extended: true, limit: '150mb'
}));
app.use(bodyParser.json({ limit: '150mb' }));



//DATABASE URL
//K7hjtgLvX5lskqPW
mongoose.connect(process.env.MONGOURL || 'mongodb+srv://sherintestingpurpose:QwTigY4aPVmJKLvd@cluster0.bklpv4v.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', ).then(() => { 
    console.log("Data Base connected")
}).catch((ex) => {
    console.log("Db connection error")
    console.log(ex)
});

//database connection
var db = mongoose.connection;




//Port Declaration
var port = process.env.PORT || 5040;





//Cors and helmet use
app.use(cors());
app.use(helmet({crossOriginResourcePolicy:false}));

//Consoles the user information and API calls into the server Environment
app.use(useragent.express());
app.use((req, res, next) => {
    var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    console.log(fullUrl)
    next();
})



//function route usage
app.use(category);
app.use(pet);
app.use(success);



//Route for checking the server health
app.get('/health', async(req, res) => {
    res.status(200).json({
        status: true
    });
    return
});

app.get('/server/time',async(req,res)=>{
    console.log("Function /server/time Called.");
    console.log(new Date())
})




//Server Environment set up
const server = app.listen(port, function () {
    console.log("Running Server on port " + port);
});








