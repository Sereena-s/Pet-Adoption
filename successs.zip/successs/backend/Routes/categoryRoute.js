const express = require('express');
var router = express.Router();
var CategoryModel=require("../Models/categoryModel");




router.post("/category/add",async(req,res)=> {
   try{

   var { name } = req.body
   if(name== null || name == undefined|| name == ""){

    res.status(200).json({
        status: false,
        msg: "invalid name",


    })
    return;
}
var categoryexists=await CategoryModel.findOne({ status:"Active",name:name})
if(categoryexists != null){
 res.status(200).json({
     status: false,
     msg: "this category alreadyexists",


 })
 return;

}
var data = new CategoryModel();
data.name = name;

await data.save();
console.log(data._id);

res.status(200).json({
    status: true,
    msg: "category adding success",
    detail: data


})
return;





   }
   catch(e){
     console.log(e)
   }
})

router.post("/category/delete", async(req,res)=> {
    try{
        var { id } = req.body
   if(id== null || id== undefined){

    res.status(200).json({
        status: false,
        msg: "invalid id",


    })
    return;

}
 var data=await CategoryModel.findOne({status :"Active",_id:id});
 if(data== null || data== undefined){

    res.status(200).json({
        status: false,
        msg: "data to be deleted not found",


    })
    return;
    
    }
    data.status="Deleted"
    await data.save()
    res.status(200).json({
        status: true,
        msg: "success!! deleted"


    })
    return;

}
    catch(e){

    }
       

})
router.get("/category/list", async(req,res)=> {
    try{
        var cat=await CategoryModel.find({status:"Active"})
        console.log(cat)
        res.status(200).json({
            status: true,
            msg: cat
    
    
        })
        return;


    }
    catch(e){
        console.log(e)

    }

})

router.post("/category/view", async(req,res)=> {
    try{
        var { id } = req.body
   if(id== null || id== undefined){

    res.status(200).json({
        status: false,
        msg: "invalid id",


    })
    return;

}
 var data=await CategoryModel.findOne({status :"Active",_id:id});
 if(data== null || data== undefined){

    res.status(200).json({
        status: false,
        msg: "category not found",


    })
    return;
    
    }
    res.status(200).json({
        status: true,
        msg: data


    })
    return;
    

   

}
    catch(e){

    }
       

})

router.post("/category/edit", async(req,res)=> {
    try{
        var { id,name } = req.body
   if(id== null || id== undefined){

    res.status(200).json({
        status: false,
        msg: "invalid id",


    })
    return;

    }
    if(name== null || name== undefined){

        res.status(200).json({
            status: false,
            msg: "invalid name"
    
    
        })
        return;
    

}
var data=await CategoryModel.findOne({status :"Active",_id:id});

   data.name=name;
   await data.save()
   res.status(200).json({
    status: true,
    msg: data


})
return;

   


}
    catch(e){

    }
})

module.exports = router;