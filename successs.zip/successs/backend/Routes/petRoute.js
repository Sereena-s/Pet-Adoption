const express = require("express");
const router = express.Router();
const multer = require("multer");
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });
const PetModel = require("../Models/petModel");
const CategoryModel = require("../Models/categoryModel"); // Import the category model

router.post("/pet/add", upload.single("image"), async (req, res) => {
    try {
        const { name, age, breed, gender, status, categoryName } = req.body;
        
        // First, find or create the category
        let category = await CategoryModel.findOne({ name: categoryName });
        if (!category) {
            // If the category doesn't exist, create a new one
            var data = new CategoryModel();
            data.name = categoryName;
            await data.save();
            console.log("new category created");
        }

        // Then create the pet with the category's ObjectId
        const newPet = new PetModel({
            name,
            age,
            breed,
            gender,
            status,
            category: category._id, // Use the category ObjectId here
            image: {
                data: req.file.buffer,
                contentType: req.file.mimetype,
            },
        });

        await newPet.save();
        res.json({ message: "Pet added successfully", pet: newPet });
    } catch (error) {
        console.error("Error adding new pet:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});


router.get("/list/pets", async (req, res) => {
    try {
        // Fetch all pets from the database
        const pets = await PetModel.find({status:"Available"});

        // If no pets found, send an appropriate response
        if (!pets || pets.length === 0) {
            return res.status(404).json({ message: "No pets found" });
        }

        // Map the pets to include only necessary information (name and image)
        const petList = pets.map(pet => ({
            name: pet.name,
            image: `data:${pet.image.contentType};base64,${pet.image.data.toString("base64")}`
        }));

        // Send the list of pets with their names and images
        res.json({ count: petList.length, pets: petList });
    } catch (error) {
        console.error("Error fetching pets:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});
  


router.get('/search-and-view/pet', async (req, res) => {
    try {
        const name = req.query.name;
        // Search for available pets by name
        const pets = await PetModel.find({ 
            name: { $regex: new RegExp(name, 'i') },
            status: 'Available' 
        });
        // If no pets are found, send a 404 response
        if (pets.length === 0) {
            return res.status(404).json({ message: 'No available pets found' });
        }
        // If pets are found, retrieve details of the first one
        const pet = pets[0]; // Assuming you want details of the first matching pet
        // Convert image buffer to base64
        const imageData = pet.image.data.toString('base64');
        const imageSrc = `data:${pet.image.contentType};base64,${imageData}`;
        // Send the details of the pet found, including image
        res.json({ 
            pet: {
                name: pet.name,
                image: imageSrc,
                age: pet.age,
                breed: pet.breed,
                gender: pet.gender,
                status: pet.status,
                category: pet.category
            }
        });
    } catch (error) {
        console.error('Error searching and viewing pet:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

router.post("/pet/edit", upload.single("image"), async (req, res) => {
    try {
        const { id, name, age, breed, gender, status, categoryName } = req.body;

        if (!id) {
            return res.status(400).json({ status: false, msg: "Invalid ID" });
        }

        if (!name) {
            return res.status(400).json({ status: false, msg: "Invalid name" });
        }

        if (!age) {
            return res.status(400).json({ status: false, msg: "Invalid age" });
        }

        if (!breed) {
            return res.status(400).json({ status: false, msg: "Invalid breed" });
        }

        if (!gender) {
            return res.status(400).json({ status: false, msg: "Invalid gender" });
        }

        if (!status) {
            return res.status(400).json({ status: false, msg: "Invalid status" });
        }

        if (!categoryName) {
            return res.status(400).json({ status: false, msg: "Invalid category name" });
        }

        // Find the pet by ID
        let pet = await PetModel.findById(id);
        if (!pet) {
            return res.status(404).json({ status: false, msg: "Pet not found" });
        }

        // Find or create the category
        let category = await CategoryModel.findOne({ name: categoryName });
        if (!category) {
            // If the category doesn't exist, create a new one
            category = new CategoryModel({ name: categoryName });
            await category.save();
        }

        // Update the pet's information
        pet.name = name;
        pet.age = age;
        pet.breed = breed;
        pet.gender = gender;
        pet.status = status;
        pet.category = category._id; // Use the category ObjectId here

        // If a new image is uploaded, update the image data
        if (req.file) {
            pet.image = {
                data: req.file.buffer,
                contentType: req.file.mimetype,
            };
        }

        await pet.save();

        res.status(200).json({ status: true, msg: "Pet updated successfully", pet });
    } catch (error) {
        console.error("Error editing pet:", error);
        res.status(500).json({ status: false, error: "Internal Server Error" });
    }
});

router.post("/pet/delete", async (req, res) => {
    try {
        const { id } = req.body;

        if (!id) {
            res.status(400).json({
                status: false,
                msg: "Invalid pet ID"
            });
            return;
        }

        // Find the pet by ID
        const pet = await PetModel.findOne({ _id: id });

        if (!pet) {
            res.status(404).json({
                status: false,
                msg: "Pet not found"
            });
            return;
        }

        // Update the status of the found pet to "Deleted"
        pet.status = "Deleted";
        await pet.save();

        res.status(200).json({
            status: true,
            msg: "Pet deleted successfully",
            deletedPet: pet
        });
    } catch (error) {
        console.error("Error deleting pet:", error);
        res.status(500).json({
            status: false,
            msg: "Internal Server Error"
        });
    }
});



module.exports = router;





















module.exports = router;
