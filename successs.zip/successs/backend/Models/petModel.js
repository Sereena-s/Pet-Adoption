 var mongoose = require('mongoose');

var petSchema = mongoose.Schema({
    name: {
        type: String
    },
   
    image: {
        data: Buffer,
        contentType: String
    },
    age: {
        type: Number
    },
    breed: {
        type: String
    },
    gender: {
        type: String
    },
    status: {
        type: String,
        default: "Available"
    },
    category:{
        type:mongoose.Schema.Types.ObjectId,ref:"categoryModel"
    }
    
},



{
    timestamps: { createdAt: 'create_date', updatedAt: 'update_date' }
});

var PetModel = module.exports = mongoose.model('PetModel', petSchema);

module.exports.get = function (callback, limit) {
    PetModel.find(callback).limit(limit);
}
